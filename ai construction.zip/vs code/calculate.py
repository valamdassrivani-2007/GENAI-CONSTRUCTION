def calculate_project(area, floors):

    total_area = area * floors

    workers = int(total_area / 60)

    cement = total_area * 0.4
    steel = total_area * 3
    sand = total_area * 0.6

    labor_cost = total_area * 500
    material_cost = total_area * 800

    total_cost = labor_cost + material_cost

    timeline = int(total_area / 120)

    return {
        "total_area": total_area,
        "workers": workers,
        "cement": cement,
        "steel": steel,
        "sand": sand,
        "total_cost": total_cost,
        "timeline": timeline
    }