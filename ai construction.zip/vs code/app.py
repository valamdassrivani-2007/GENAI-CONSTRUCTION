from Flask import Flask, render_template, request, jsonify
from calculate import calculate_project
from ai_engine import get_ai_analysis
from schedule import generate_schedule

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze():

    data = request.json
    area = float(data["area"])
    floors = int(data["floors"])

    calculation = calculate_project(area, floors)

    schedule = generate_schedule()

    ai = get_ai_analysis(area, floors)

    return jsonify({
        "calculation": calculation,
        "schedule": schedule,
        "ai": ai
    })

if __name__ == "__main__":
    app.run(debug=True)