def generate_schedule():

    schedule = [
        "Week 1-2 : Site Preparation & Excavation",
        "Week 3-4 : Foundation Work",
        "Week 5-7 : Structural Columns & Beams",
        "Week 8-10 : Brickwork & Walls",
        "Week 11-12 : Roofing",
        "Week 13-14 : Electrical & Plumbing",
        "Week 15 : Plastering",
        "Week 16 : Painting & Finishing"
    ]

    return schedule