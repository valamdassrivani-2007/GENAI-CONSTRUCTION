async function analyze(){

let area=document.getElementById("area").value
let floors=document.getElementById("floors").value

let response = await fetch("/analyze",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({area:area,floors:floors})
})

let data=await response.json()

let calc=data.calculation

let html=`
<h2>Project Analysis</h2>

Total Area: ${calc.total_area}<br>
Workers Required: ${calc.workers}<br>
Cement: ${calc.cement}<br>
Steel: ${calc.steel}<br>
Sand: ${calc.sand}<br>
Total Cost: ${calc.total_cost}<br>
Timeline: ${calc.timeline} days<br>

<h3>Schedule</h3>
${data.schedule.join("<br>")}

<h3>AI Advice</h3>
${data.ai}
`

document.getElementById("result").innerHTML=html
}