import requests

def get_ai_analysis(area, floors):

    prompt = f"""
    Construction project planning.

    Area: {area} sq yards
    Floors: {floors}

    Provide:
    - workforce planning
    - risk factors
    - construction advice
    """

    response = requests.post(
        "http://localhost:11434/api/generate",
        json={
            "model": "granite:3.3-2b",
            "prompt": prompt,
            "stream": False
        }
    )

    return response.json()["response"]